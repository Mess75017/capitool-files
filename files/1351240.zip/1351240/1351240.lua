addappid(1351240)
addappid(1351241, 1, "9e79fc452f59614517425d51bae47b42451e0a8aaba07aa8b48b756424d68539")
setManifestid(1351241, "9031186204250406665", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]